#ifndef UART_H
#define UART_H

#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define START_BIT 0x80
#define ACK true
#define NACK false
#define BIT_FLIP_PROB 0.001

void App_driver(char *);
bool bus(unsigned char);
bool Device_driver(unsigned char);
void Device_app(char *);

static inline bool compute_parity(unsigned char byte) {
    int p = 0;
    for (int i = 0; i < 7; i++)
        p ^= (byte >> i) & 1;
    return p == 0;
}

#endif
