#include "uart.h"

int main() {
    char str[512];
    sprintf(str, "123456789101%dAB", 25);
    App_driver(str);  // send to driver
    return 0;
}
