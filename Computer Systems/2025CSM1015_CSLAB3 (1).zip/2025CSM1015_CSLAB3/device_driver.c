#include "uart.h"

bool Device_driver(unsigned char byte) {
    static unsigned char memory[128] = {0};
    static int address = 0;
    static int state = 0;
    static int received = 0;

    if (byte == START_BIT) {
        state = 0;
        return ACK;
    }

    unsigned char data = byte >> 1;
    bool parity = byte & 1;

    if (compute_parity(data) != parity) {
        printf("Parity error on byte,repeating the same address again: %u\n", byte);
        return memory[address];
    }

    if (state == 0) {
        if (data >= 128) {
            printf("Invalid address: %u\n", data);
            return memory[address];
        }
        address = data;
        state = 1;
        return ACK;
    } else {
        if (address < 128) {
            memory[address++] = data;
        } else {
            printf("Address overflow: %d\n", address);
        }
        received++;
        if (received == 4) {
            received = 0;
            Device_app((char *)memory);
        }
        return ACK;
    }
}
