#include "uart.h"

void App_driver(char *str) {
    int len = strlen(str);
    int i = 0, addr = 0;

    while (i < len) {
        for (int j = 0; j < 4 && i < len; j++, i++, addr++) {
            if (!bus(START_BIT)) continue;

            unsigned char address = (unsigned char)(addr & 0x7F);
            unsigned char addr_frame = (address << 1) | compute_parity(address);
            if (!bus(addr_frame)) continue;

            unsigned char data = (unsigned char)str[i] & 0x7F;
            unsigned char data_frame = (data << 1) | compute_parity(data);
            if (!bus(data_frame)) continue;
        }
    }
}
