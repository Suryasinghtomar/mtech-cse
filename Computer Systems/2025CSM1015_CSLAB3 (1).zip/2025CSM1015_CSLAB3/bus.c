#include "uart.h"
#include <stdlib.h>

bool bus(unsigned char byte) {
    double prob = (double) rand() / RAND_MAX;
    if (prob < BIT_FLIP_PROB) {
        int bit = rand() % 8;
        byte ^= (1 << bit);  // flip one random bit
    }
    return Device_driver(byte);
}
