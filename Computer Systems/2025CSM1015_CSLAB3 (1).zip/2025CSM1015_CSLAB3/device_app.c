#include "uart.h"

void Device_app(char *memory) {
    for (int i = 0; i < 128; i++) {
        putchar(memory[i] ? memory[i] : '.');
        if ((i + 1) % 32 == 0) putchar('\n');
    }
}
